<?php	phpinfo(); ?>
