BEGIN;

INSERT INTO users VALUES ( 4, 'Zoocam', 'Admin', 'zooadmin', 'Z00cam!', 1, date('now'), time('now'), NULL, NULL);

COMMIT;
